#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <wait.h>

void fjprincipal(int sig);
void fjpista(int sig);
void fkarts(int sig);
int calculaAleatorios(int min, int max);
int juezp;
	
int main(int argc, char *argv[]) {
	if (argc < 2) {				//COMPROBACIÓN ARGUMENTOS
       		printf("Número de argumentos erróneo\n");
	return 0;
   	}

	int num = atoi(argv[1]);		//DECLARACIÓN VARIABLES
	int* hijos;
	pid_t p;
	printf("\n");			
	printf("INFO: Se va a iniciar la carrera con %d Karts.\n",num);				
	srand (time(NULL));			
	hijos = (int*)malloc(sizeof(int)*num);

	for(int i = 0; i < num +1; i++) {	//Tantos como desea el usuario
		p = fork();
		if(p == -1) perror("Error en la llamada a fork()");
		else if (p == 0) {
		   switch(i) {
			case 0:			//CREACIÓN J. Pista
				juezp = getpid();
			   break;
			default:		//CREACIÓN Karts
			   break;
	
		}	break;
		} else hijos[i] = p;		//CREACIÓN J. Principal
	}

	// Procedemos a diseñar la interacción de los mismos
	
	if (p == 0){      	 //Hijos  			
		sleep(1);			
		if(getpid() == juezp) { 	// JUEZ PISTA**********************
			printf("--> JUEZ DE PISTA: Bienvenidos a la carrera, mi ID es %d.\n", getpid());	
			printf("\n");
			signal(SIGUSR1, fjpista);
			while(1)
				pause();


		} else {			// KARTS***************************
			sleep (1);
			printf("INFO: El Kart con matrícula %d tiene por Padre al nº %d.\n", getpid(),getppid());		
			signal(SIGUSR1, fkarts);
			while(1)
				pause();


	}} else {				// JUEZ PRINCIPAL******************		
		int estado;
		int seconds;
		juezp = hijos[0];
		printf("\n");		
		printf("--> JUEZ PRINCIPAL: Buenas a todos, mi ID es %d.\n", getpid());
		sleep(3);	
		kill(juezp, SIGUSR1);
		printf("\n");
		printf("--> JUEZ PRINCIPAL: ¿Se encuentra en buen estado la pista, Juez de Pista?\n");	
		signal(SIGUSR1, fjprincipal);
		signal(SIGUSR2, fjprincipal);
		pause();
		wait(&juezp);
		//Principal recibe estado de la pista (continuamos en manejadora)
		for(int i = 1; i < num + 1; i++) {
				kill(hijos[i], SIGUSR1);
			}
		//Imprimimos resultados de la carrera
		printf("\n");
		for(int i = 1; i < num + 1; i++) {
			p = wait(&estado);
			seconds = WEXITSTATUS(estado);
			printf("\n");
			printf("--> JUEZ PRINCIPAL: El Kart con matrícula %d ha finalizado en %dº posición con un tiempo de %d segundos.\n", p , i , seconds);
		}
		printf("\n");
		printf("INFO: La carrera de Karts ha finalizado.\n");
		printf("\n");

		free(hijos);
	return 0;
	}
	}					// FIN MAIN
	

void fjpista(int sig) {		//MANEJADORA JUEZ PISTA
	printf("--> JUEZ DE PISTA: Lo comprobaré.\n");
	sleep(5);
	srand(time(0));
	do {	
		printf("--> JUEZ DE PISTA: La pista NO está lista.\n");		
		kill(getppid(), SIGUSR1); 	//0 -> NO está lista SIGURSR1 y envío señal
		sleep(3);

	} while(calculaAleatorios(0,1) == 0);
		printf("--> JUEZ DE PISTA: La pista SI está lista.\n");
		kill(getppid(), SIGUSR2);	//1 -> SI está lista SIGUSR2 y envío señal
		exit(juezp);
}


void fjprincipal(int sig) {	//MANEJADORA JUEZ PRINCIPAL
	if(sig == SIGUSR1){	//Si recibe "NO lista"
			printf("--> JUEZ PRINCIPAL: Recibido. Esperaremos a que lo esté, Juez de Pista.\n");
			sleep(3);
			kill(juezp, SIGUSR1);

		} else if(sig == SIGUSR2){	//Si recibe "SI lista"
		printf("\n");
		printf("--> JUEZ PRINCIPAL: Perfecto. Pilotos, en sus marcas...\n");
		sleep(1);
		printf("--> JUEZ PRINCIPAL: Listooos...\n");
		sleep(2);
		printf("--> JUEZ PRINCIPAL: ¡¡ YA !!\n");
		}
}
int calculaAleatorios(int min, int max) {
return rand() % (max-min+1) + min;
}

void fkarts(int sig) {	       //MANEJADORA KARTS
	int tiempo;
	printf("\n");
	printf("INFO: ¡El Kart con matrícula %d ha salido!\n", getpid());
	srand(getpid());
	sleep(tiempo = calculaAleatorios(1,5));
	exit(tiempo);
}

//Iván Castro Martínez
