#!/bin/bash

red='\e[0;31m'
blue='\e[0;34m'
endColor='\e[0m'

#Iniciamos la Shell
echo -e "\n${red}Bienvenido a la Shell de Karts.${endcolor}"

while true
do
#Visualizamos el menú de opciones
echo -e "${red}Seleccione una de las siguientes opciones:${endColor}\n"

echo -e "\t${blue}1. Visualizar el código de Karts.${endColor}\n"
echo -e "\t${blue}2. Compilación del Karts.${endColor}\n"
echo -e "\t${blue}3. Ejecución de Karts. Recuerde introducir cuantos karts ${endColor}\n"
echo -e "\t${blue}4. Salir.${endColor}\n"

read option
case $option in
	1) cat picodigo.c ;;
	2) gcc -o exekarts picodigo.c  
	   echo -e "Programa compilado.\n" ;;
	3) if test -x exekarts
		then	echo -e "Por favor, introduzca cuantos corredores participarán: "
			read numkarts
			./exekarts $numkarts
		else	echo -e "No puede ejecutar el programa\n" 
	   fi ;;
	4) break ;;
	*) echo -e "\n${red}Opción no válida. Escoja una de las opciones listadas.${endColor}\n" ;;
  esac
done

# Iván Castro Martínez
