/**
 * Practica final: Aeropuerto nacional catalan Carles Puigdemon
 * 
 * Raúl Fernández Moro
 * Iván Castro Martínez
 * Aitor del Río Ferreras
 * Raúl González Martínez
 * 
 **/

/* Inclusion de librerias */
#include <pthread.h> // Para la creacion de hilos
#include <time.h>    // Para el uso de la fecha
#include <stdio.h>   // Para imprimir mensajes en pantalla
#include <signal.h>  // Para manejar senales
#include <stdlib.h>  // Para usar sprintf
#include <unistd.h>  // Para usar la funcion sleep
#include <limits.h>  // Para obtener el maximo de int

/* Declaracion de funciones que seran necesarias en el desarrollo */
int pasajerosTipo(int tipo);
void nuevoPasajero(int s);
void *accionesPasajero(void *posicion);
void *accionesFacturador(void *tipo);
int porcentajeAleatorio();
int numeroAleatorio(int minimo, int maximo);
void escribirLog(char *id, char *msg);
void *accionesAgentes();
int damePasajero();
void cerrarAeropuerto(int arg);

/* Constantes que establecen el numero de elementos*/
#define PASAJEROS 10
#define FACTURADORES 2
#define AGENTES 1

/* Declaracion de los semaforos y de las variables condicion */
pthread_mutex_t mAeropuerto;
pthread_mutex_t mPasajero;
pthread_mutex_t mAtencion;
pthread_mutex_t mEscritura;
pthread_mutex_t mComprobacionControl;
pthread_mutex_t mPasajeroEnControl;
pthread_mutex_t mAgente;
pthread_cond_t entradaControl;
pthread_cond_t salidaControl;

/* Estructura que lleva los datos a conocer de los pasajeros */
struct pasajero
{
    int id;             // Aqui guardamos el identificador del pasajero
    int facturado;      // Guardamos como 0 que aun no ha facturado , 1 como que esta facturando y  como 2 que ya ha pasado la facturacion
    int atendido;       // Guardamos como 0 que el pasajero no ha sido atendido, como 1 que el pasajero esta siendo atendido y como 2 que ya ha sido atendido
    int tipo;           // Guardamos como 1 que el pasajero es normal y como 2 que el pasajero es vip (0 es la inicializacion)
    pthread_t pasajero; // Hilo
};

struct pasajero pasajeros[PASAJEROS]; // Array donde se guardaran hasta un maximo de 10 pasajeros

/* Estructura que guarda la informacion de los facturadores */
struct facturador
{
    int id;                 // El identificador del facturador
    int tipo;               // Al igual que en los pasajeros
    int trabajando;         // Si esta en ese momento facturando
    int pasajerosAtendidos; // Pasajeros que ha atendido para tomar el cafe
    pthread_t facturador;   // Hilo
};

struct facturador facturadores[FACTURADORES]; // Array donde se almacenan los facturadores

pthread_t agente; // El hilo del agente de seguridad

/* Variables globales */
// El ultimo id del pasajero
int ultimoPasajero;
// Contador de usuarios (hasta 10)
int contPasajeros;
// Si esta pasando el control un usuario
int usuarioEnControl;

/* Declaracion del log */
FILE *archivoLog;
char *nombreLog;

/* MAIN */
int main()
{
    /* Generacion de semilla aleatoria */
    srand(time(NULL));

    /* Armar las senales del usuario normal y del vip */
    struct sigaction entradaPasajero;
    entradaPasajero.sa_handler = nuevoPasajero;
    entradaPasajero.sa_flags = SA_NODEFER; // Para interrumpir la manejadora con otra senal
    // Si no es correcto se informa y se sale del programa
    if (sigaction(SIGUSR1, &entradaPasajero, NULL) == -1)
    {
        perror("ERROR: No se puede comprobar si un pasajero normal va a entrar");
        exit(-1);
    }
    else if (sigaction(SIGUSR2, &entradaPasajero, NULL) == -1)
    {
        perror("ERROR: No se puede comprobar si un pasajero VIP va a entrar");
        exit(-1);
    }
    struct sigaction terminarAeropuerto;
    terminarAeropuerto.sa_handler = cerrarAeropuerto;
    terminarAeropuerto.sa_flags = SA_NODEFER;

    if (sigaction(SIGINT, &terminarAeropuerto, NULL) == -1)
    { //Señal que hace indica la salida del programa con kill
        perror("ERROR : Ha ocurrido algo mientras se realizaba la señal");
        exit(-1);
    }

    /* Inicializacion del log */
    nombreLog = "registroAeropuerto.log";
    archivoLog = fopen(nombreLog, "w");
    fclose(archivoLog);
    escribirLog("AeropuertoCP", "Se ha iniciado la actividad del aeropuerto.");

    /* Inicializacion de mutex */
    if (pthread_mutex_init(&mAeropuerto, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_mutex_init(&mEscritura, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_mutex_init(&mPasajero, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_mutex_init(&mAtencion, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_mutex_init(&mComprobacionControl, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_mutex_init(&mPasajeroEnControl, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_cond_init(&entradaControl, NULL) != 0)
    {
        exit(-1);
    }
    if (pthread_cond_init(&salidaControl, NULL) != 0)
    {
        exit(-1);
    }

    pthread_mutex_lock(&mAeropuerto);

    /* Inicializacion de las variables globales */
    ultimoPasajero = 0;
    contPasajeros = 0;
    usuarioEnControl = 0;

    /* Inicializar al array de pasajeros */
    int i;
    for (i = 0; i < PASAJEROS; i++)
    {
        pasajeros[i].id = 0;
        pasajeros[i].facturado = 0;
        pasajeros[i].atendido = 0;
        pasajeros[i].tipo = 0;
    }
    int j;
    /* Inicializar el array de facturadores */
    for (j = 0; j < FACTURADORES; j++)
    {
        facturadores[j].id = j + 1;
        facturadores[j].tipo = j + 1;
        facturadores[j].trabajando = 0;
        facturadores[j].pasajerosAtendidos = 0;
    }

    pthread_mutex_unlock(&mAeropuerto);
    int k;
    /* Creamos los hilos facturadores */
    for (k = 0; k < FACTURADORES; k++)
    {
        // Argumento para que el hilo del facturador sepa su indice en el array
        int *indiceF = malloc(sizeof(*indiceF));
        *indiceF = k;
        // Creacion del hilo
        pthread_create(&facturadores[k].facturador, NULL, accionesFacturador, indiceF); // en lugar de acciones pasajeras no hay que poner algo como acciones facturador ???
    }

    // Creamos el hilo agente de control
    pthread_create(&agente, NULL, accionesAgentes, NULL);

    // Esperar señales SIGUSR1 y SIGUSR2 infinitamente
    while (1)
    {
        pause();
    }

    return 0;
}
/* FIN MAIN */

void nuevoPasajero(int sig)
{
    //activamos el mutex para evitar que se creen dos pasajeros a la vez, tiene que ser uno tras otro
    pthread_mutex_lock(&mPasajero);

    //comprobamos que haya sitio si no el pasajero se va al no haber espacio
    if (contPasajeros < PASAJEROS)
    {
        // Posicion dentro del array del pasajero
        int posicion = 0;

        // Busca la primera posicion libre (con id igual a 0)
        for (int i = 0; i < PASAJEROS; ++i)
        {
            if (pasajeros[i].id == 0)
            {
                posicion = i;
                break; // Sale del bucle al encontrar la posicion
            }
        }

        // Posicion en el array actual de los pasajeros
        int *contP = malloc(sizeof(*contP));
        *contP = posicion;

        // No factura todavia
        pasajeros[posicion].facturado = -1;

        // Se establece el id del pasajero (se suma 1 para añadirlo)
        ultimoPasajero++;
        pasajeros[posicion].id = ultimoPasajero;

        //comprobamos el tipo de señal que ha sido enviada y en funcion de dicha señal, sera un tipo de pasajero u otro
        //primero evaluamos el caso en que es usuario sea de tipo normal
        if (sig == SIGUSR1)
        {
            pasajeros[posicion].tipo = 1; //indicamos que como la señal es SIGUSR1, el pasajero tiene ticket normal
            //aumentamos en numero de pasajeros en cola
        }
        // se evalua en este caso que el usuario sea de tipo VIP
        else if (sig == SIGUSR2)
        {
            pasajeros[posicion].tipo = 2; //como la señal enviada es SIGUSR2, el usuario es de tipo vip
            //aumentamos en numero de pasajeros en cola
        }

        pthread_create(&pasajeros[posicion].pasajero, NULL, accionesPasajero, contP); //lanzamos el hilo

        pthread_mutex_lock(&mEscritura);
        char id[20];
        char mensaje[100];
        sprintf(id, "pasajero_%d", pasajeros[posicion].id);
        sprintf(mensaje, "El pasajero acaba de entrar en el aeropuerto.", pasajeros[posicion].id);
        escribirLog(id, mensaje);
        pthread_mutex_unlock(&mEscritura);

        // Se aumenta el contador de pasajeros al haberse creado correctamente
        contPasajeros++;
    }
    else
    {
        pthread_mutex_lock(&mEscritura);
        escribirLog("AeropuertoCP", "Un pasajero ha llegado al aeropuerto, pero no queda espacio en la cola y se va.");
        pthread_mutex_unlock(&mEscritura);
    }

    // Desbloqueamos el mutex
    pthread_mutex_unlock(&mPasajero);
}
//funcion que lleva a cabo las acciones del pasajero una vez ha sido registrado
void *accionesPasajero(void *posicion)
{
    //transformamos la posicion void en un numero utilizable
    int pos = *(int *)posicion;
    free(posicion);

    // Se guarda el id del usuario
    char id[20];
    char mensaje[100];
    sprintf(id, "pasajero_%d", pasajeros[pos].id);

    //  1. Guardar en el log la hora de entrada.
    //2. Guardar en el log el tipo de usuario.
    pthread_mutex_lock(&mEscritura);
    sprintf(mensaje, "Se coloca en la cola un pasajero del tipo %d.", pasajeros[pos].tipo);
    escribirLog(id, mensaje);
    pthread_mutex_unlock(&mEscritura);

    // Ya puede facturar
    pasajeros[pos].facturado = 0;

    // la variable estado genera un numero aleatorio para saber los porcentajes de clientes que hacen determinadas acciones
    int estado = 0;

    //3. Duerme 4 segundos
    sleep(4);

    //4. Comprueba si está siendo atendido.
    pthread_mutex_lock(&mAtencion);
    while (pasajeros[pos].atendido == 0 && pasajeros[pos].facturado == 0)
    { //5.Mientras no sea atendido
        pthread_mutex_unlock(&mAtencion);
        estado = porcentajeAleatorio();
        if (estado < 30)
        {
            //El 30% de los pasajeros han ido al baño o se han cansado de esperar y abandonan la cola
            pasajeros[pos].facturado = 2;
            //Log pasajero abandona cola
            if (estado < 10)
            {
                pthread_mutex_lock(&mEscritura);
                sprintf(mensaje, "El pasajero %d ha salido de la cola y se va al baño.", pasajeros[pos].id);
                escribirLog(id, mensaje);
                pthread_mutex_unlock(&mEscritura);
            }
            else if (estado > 10)
            {
                pthread_mutex_lock(&mEscritura);
                sprintf(mensaje, "El pasajero %d ha salido de la cola porque se canso de esperar.", pasajeros[pos].id);
                escribirLog(id, mensaje);
                pthread_mutex_unlock(&mEscritura);
            }
            //Pasajero abandona cola, fin del hilo
            pthread_mutex_lock(&mAtencion);
            //Limpio el pasajero actual
            pasajeros[pos].id = 0;
            pasajeros[pos].facturado = 0;
            pasajeros[pos].atendido = 0;
            pasajeros[pos].tipo = 0;
            contPasajeros--;
            pthread_mutex_unlock(&mAtencion);

            pthread_exit(NULL);
        }
        else
        {
            //El 70% restante, duerme y vuelve al punto 4
            sleep(4);
        }
    }
    pthread_mutex_unlock(&mAtencion);

    //6.Esperamos en función del facturador asignado a que termine de ser atendido con wait
    while (pasajeros[pos].facturado == 0)
    {
    }

    //Ha terminado de ser atendido
    //7.
    //a.Ya ha sido facturado tiene que esperar por control
    if (pasajeros[pos].facturado == 2)
    {
        pthread_mutex_lock(&mEscritura);
        sprintf(mensaje, "El pasajero %d ha salido de la facturación y se dirige al control de seguridad.", pasajeros[pos].id);
        escribirLog(id, mensaje);
        pthread_mutex_unlock(&mEscritura);
    }
    else if (pasajeros[pos].facturado == 1)
    {
        pthread_mutex_lock(&mEscritura);
        sprintf(mensaje, "El pasajero %d no ha podido facturar por problemas en el visado y se va del aeropuerto.", pasajeros[pos].id);
        escribirLog(id, mensaje);
        pthread_mutex_unlock(&mEscritura);

        //Pasajero abandona la cola
        pthread_mutex_lock(&mAeropuerto);
        //Limpio el pasajero actual
        pasajeros[pos].id = 0;
        pasajeros[pos].facturado = 0;
        pasajeros[pos].atendido = 0;
        pasajeros[pos].tipo = 0;
        contPasajeros--;
        pthread_mutex_unlock(&mAeropuerto);
        //Fin del hilo
        pthread_exit(NULL);
    }
    pthread_mutex_lock(&mComprobacionControl);
    // Espera hasta que el control este libre
    while (usuarioEnControl == 1)
        ;
    usuarioEnControl = 1;
    pthread_cond_signal(&entradaControl);

    pthread_mutex_unlock(&mPasajeroEnControl);
    pthread_cond_wait(&salidaControl, &mPasajeroEnControl);
    pthread_mutex_unlock(&mPasajeroEnControl);

    pthread_mutex_unlock(&mComprobacionControl);

    usuarioEnControl = 0;

    //Log pasajero embarca
    pthread_mutex_lock(&mEscritura);
    sprintf(mensaje, "El pasajero %d ha pasado el control por lo que procede a embarcar.", pasajeros[pos].id);
    escribirLog(id, mensaje);
    pthread_mutex_unlock(&mEscritura);

    pthread_mutex_lock(&mAeropuerto);
    //Limpio el pasajero actual
    pasajeros[pos].id = 0;
    pasajeros[pos].facturado = 0;
    pasajeros[pos].atendido = 0;
    pasajeros[pos].tipo = 0;
    contPasajeros--;
    pthread_mutex_unlock(&mAeropuerto);

    // EL hilo sale
    pthread_exit(NULL);
}

/* Aqui se recogeran las acciones que realize el facturador que estara identificado con el
 * el nombre facturador_X, donde la X sera el tipo de facturador (0=normal, 1=VIP).
 */
void *accionesFacturador(void *indice)
{
    int indiceF = *(int *)indice; // Toma el tipo de facturador del argumento
    free(indice);                 // Libera el espacio del puntero
    int pasajeroActual;           // Usuario que se esta tratando
    char mensaje[100];            // Aqui se guardaran los mensajes impresos por pantalla

    // Establezco el indice del facturador
    char facturador[20];
    sprintf(facturador, "facturador_%d", facturadores[indiceF].id);

    // Facturador listo
    pthread_mutex_lock(&mEscritura);
    escribirLog(facturador, "Esta preparado para atender a los pasajeros");
    pthread_mutex_unlock(&mEscritura);

    while (1)
    {
        // Mientras que el facturador este disponible
        while (facturadores[indiceF].trabajando == 0)
        {
            // Establece un id para comparar (el mayor posible es el que mas ha esperado)
            int idMayorTiempo = INT_MAX;
            // Inicio zona critica
            pthread_mutex_lock(&mAeropuerto);

            // Busco un pasajero que cumpla las condiciones
            // Que sea de mi tipo y no haya sido atendido
            for (int i = 0; i < PASAJEROS; i++)
            {
                if (pasajeros[i].id != 0 && facturadores[indiceF].tipo == pasajeros[i].tipo && pasajeros[i].atendido == 0 && pasajeros[i].facturado == 0)
                {
                    // Toma al pasajero que lleve mas tiempo esperando
                    if (pasajeros[i].id < idMayorTiempo)
                    {
                        idMayorTiempo = pasajeros[i].id;
                        pasajeroActual = i;
                        // El pasajero va a ser atendido
                        pasajeros[pasajeroActual].atendido = 1;
                        // El facturador se mantiene ocupado con el pasajero
                        facturadores[indiceF].trabajando = 1;

                        // Fin zona critica
                        pthread_mutex_unlock(&mAeropuerto);
                    }
                }

                // Busco pasajero del otro tipo y soy vip y hay mas de dos en el otro
                if (facturadores[indiceF].trabajando == 0 && facturadores[indiceF].tipo == 2 && pasajerosTipo(1) > 1)
                {
                    if (pasajeros[i].id != 0 && pasajeros[i].atendido == 0 && pasajeros[i].facturado == 0)
                    {
                        // Toma al pasajero que lleve mas tiempo esperando
                        if (pasajeros[i].id < idMayorTiempo)
                        {
                            idMayorTiempo = pasajeros[i].id;
                            pasajeroActual = i;

                            // El pasajero va a ser atendido
                            pasajeros[pasajeroActual].atendido = 1;
                            // El facturador se mantiene ocupado con el pasajero
                            facturadores[indiceF].trabajando = 1;

                            // Fin zona critica
                            pthread_mutex_unlock(&mAeropuerto);
                        }
                    }
                }
            }

            // Desbloqueo el mutex por si no hubiera ningun usuario que atender
            pthread_mutex_unlock(&mAeropuerto);
        }

        // A partir de aqui ya ha llegado el pasajero y va a empezar su facturacion

        // Calcula la situacion aleatoria
        int porcentaje = porcentajeAleatorio();
        int tiempoEspera = 0;
        int expulsion = 0; // Si no tiene el visado en regla
        char motivo[100];
        if (porcentaje < 80)
        {
            // Facturacion valida
            tiempoEspera = numeroAleatorio(1, 4);
            sprintf(motivo, "El pasajero %d ha facturado sin problemas", pasajeros[pasajeroActual].id);
        }
        else if (porcentaje >= 80 && porcentaje < 90)
        {
            // Facturacion con exceso de peso
            tiempoEspera = numeroAleatorio(2, 6);
            sprintf(motivo, "El pasajero %d ha facturado tras resolver sus problemas con el exceso de peso", pasajeros[pasajeroActual].id);
        }
        else if (porcentaje >= 90)
        {
            // Facturacion sin visado en regla, adios
            tiempoEspera = numeroAleatorio(6, 10);
            sprintf(motivo, "El pasajero %d no ha podido facturar ya que no tiene el visado en regla", pasajeros[pasajeroActual].id);
            expulsion = 1;
        }

        // Ya se va a iniciar la facturacion
        pthread_mutex_lock(&mEscritura);
        sprintf(mensaje, "El pasajero %d ha llegado al puesto de facturación y va a ser atendido", pasajeros[pasajeroActual].id);
        escribirLog(facturador, mensaje);
        pthread_mutex_unlock(&mEscritura);

        sleep(tiempoEspera);

        // El usuario ya ha sido atendido
        pthread_mutex_lock(&mEscritura);
        sprintf(mensaje, "El pasajero %d ya ha sido atendido por facturación en %d segundos", pasajeros[pasajeroActual].id, tiempoEspera);
        escribirLog(facturador, mensaje);
        pthread_mutex_unlock(&mEscritura);

        // Mensaje del motivo de facturacion
        pthread_mutex_lock(&mEscritura);
        escribirLog(facturador, motivo);
        pthread_mutex_unlock(&mEscritura);

        // El pasajero ha finalizado su atencion
        pthread_mutex_lock(&mAeropuerto);

        // Se guarda la efectividad de la facturacion
        if (expulsion == 0)
        {
            pasajeros[pasajeroActual].facturado = 2;
        }
        else
        {
            pasajeros[pasajeroActual].facturado = 1;
        }
        pthread_mutex_unlock(&mAeropuerto);
        // El pasajero ya no esta siendo atendido
        pasajeros[pasajeroActual].atendido = 0;
        // Se aumenta el contador para ir a tomar el cafe
        facturadores[indiceF].pasajerosAtendidos++;
        facturadores[indiceF].trabajando = 0;

        // Comprueba si tiene que ir a tomar el cafe
        if (facturadores[indiceF].pasajerosAtendidos == 5)
        {
            // Escribe que va a tomar el cafe
            pthread_mutex_lock(&mEscritura);
            escribirLog(facturador, "Va a tomar el cafe y deja el puesto desatendido");
            pthread_mutex_unlock(&mEscritura);

            // Toma el cafe
            sleep(10);

            // Se restablece el contador
            facturadores[indiceF].pasajerosAtendidos = 0;

            // Dice que ha vuelto del cafe
            pthread_mutex_lock(&mEscritura);
            escribirLog(facturador, "Ha vuelto de tomar el cafe y vuelve a atender a los pasajeros");
            pthread_mutex_unlock(&mEscritura);
        }
    }
}
void *accionesAgentes(void *agente)
{
    int i;
    int estado = 0;
    int accion = 0;
    char id[40];
    char mensaje[100];
    while (1)
    {
        pthread_mutex_lock(&mAgente);

        i = damePasajero();
        if (i == -1)
        {
            pthread_cond_wait(&entradaControl, &mAgente);
            i = damePasajero();
        }

        pthread_mutex_lock(&mEscritura);
        sprintf(id, "Agente");
        sprintf(mensaje, "El pasajero %d va a iniciar el control.", pasajeros[i].id);
        escribirLog(id, mensaje);
        pthread_mutex_unlock(&mEscritura);

        estado = porcentajeAleatorio();
        if (estado < 40)
        {
            accion = numeroAleatorio(10, 15);
            sleep(accion);
            pthread_mutex_lock(&mEscritura);
            sprintf(id, "Agente");
            sprintf(mensaje, "El pasajero %d ha tardado %d segundos en pasar el control por haber sido inspeccionado.", pasajeros[i].id, accion);
            escribirLog(id, mensaje);
            pthread_mutex_unlock(&mEscritura);
            pthread_mutex_lock(&mAeropuerto);
            pasajeros[i].atendido = 2;
            pthread_mutex_unlock(&mAeropuerto);
        }
        else if (estado > 40)
        {
            accion = numeroAleatorio(2, 3);
            pthread_mutex_lock(&mEscritura);
            sleep(accion);
            sprintf(mensaje, "El pasajero %d ha tardado %d segundos por no haber sido inspeccionado.", pasajeros[i].id, accion);
            escribirLog(id, mensaje);
            pthread_mutex_unlock(&mEscritura);
            pthread_mutex_lock(&mAeropuerto);
            pasajeros[i].atendido = 2;
            pthread_mutex_unlock(&mAeropuerto);
        }

        pthread_cond_signal(&salidaControl);

        pthread_mutex_unlock(&mAgente);
    }
}
/** Devuelve el numero de pasajeros de determinado tipo **/
int pasajerosTipo(int tipo)
{
    int numero = 0;
    for (int i = 0; i < PASAJEROS; i++)
    {
        // Si el id del pasajero es positivo, es del mismo tipo y no ha facturado todavia;
        if (pasajeros[i].id > 0 && pasajeros[i].tipo == tipo && pasajeros[i].facturado == 0 && pasajeros[i].atendido == 0)
        {
            numero++;
        }
    }
    return numero;
}
/* Funcion que crea un porcentaje aleatorio */
int porcentajeAleatorio()
{
    return rand() % 100;
}

/* Funcion que crea un numero aleatorio dentro de un rango */
int numeroAleatorio(int minimo, int maximo)
{
    return rand() % (maximo - minimo + 1) + minimo;
}

void escribirLog(char *id, char *msg)
{
    // Calculamos la hora actual
    time_t now = time(0);
    struct tm *tlocal = localtime(&now);
    char stnow[21];
    strftime(stnow, 21, "%d/%m/%y %H:%M:%S", tlocal);

    // Escribimos en el log
    archivoLog = fopen(nombreLog, "a");
    fprintf(archivoLog, "[%s] %s: %s\n", stnow, id, msg);
    fclose(archivoLog);
    printf("[%s] %s: %s\n", stnow, id, msg); // Muestra el mensaje en pantalla
}
int damePasajero()
{
    int i;

    for (i = 0; i < PASAJEROS; i++)
    {
        if (pasajeros[i].id > 0 && pasajeros[i].facturado == 2 && pasajeros[i].atendido == 0)
        {
            return i;
        }
    }
    return -1;
}
void cerrarAeropuerto(int arg)
{
    char mensaje[100];
    signal(SIGUSR1, SIG_IGN);
    signal(SIGUSR2, SIG_IGN);

    pthread_mutex_lock(&mEscritura);

    escribirLog("AeropuertoCP", "Se va a cerrar el aeropuerto, esperando a que se acabe la actividad...");
    pthread_mutex_unlock(&mEscritura);

    while (contPasajeros > 0 && usuarioEnControl != 0)
        ;
    //Comprobamos si antes de cerrar el programa queda alguien en facturacion
    pthread_mutex_lock(&mEscritura);
    sprintf(mensaje, "Se han atendido hoy a %d pasajeros", ultimoPasajero);
    escribirLog("AeropuertoCP ", mensaje);
    escribirLog("AeropuertoCP", "Gracias por su visita, sentimos que el aeropuerto cierre hasta mañana");
    pthread_mutex_unlock(&mEscritura);

    signal(SIGINT, SIG_DFL);
    raise(SIGINT);
    exit(0);
}